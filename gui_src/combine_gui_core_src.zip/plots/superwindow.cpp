#include "superwindow.h"
#include "ui_superwindow.h"
#include <QFileDialog>
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>

SuperWindow::SuperWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::SuperWindow)
{
    ui->setupUi(this);
    figure = addFigure();
    plot = new MainWindow();

    item_model = new QStandardItemModel(0, 1);
    ui->objectView->setModel(item_model);

    log_model = new QStandardItemModel(0, 1);
    ui->logView->setModel(log_model);
}

SuperWindow::~SuperWindow()
{
    delete ui;
}

void SuperWindow::on_pushButton_show_clicked()
{
    // reset graph
    plot->reset_graph();

    // rescale
    plot->reset_scale();
    // - by points
    int point_count = getPointsCount(figure);
    double* point_x = new double[u_int(point_count)];
    double* point_y = new double[u_int(point_count)];
    updatePoints(figure);
    for(int i = 0; i < point_count; i++){
        point_x[i] = figure->points[i].x;
        point_y[i] = figure->points[i].y;
    }
    this->plot->update_scale_by_intersects(point_x, point_y, point_count);
    // - by lines and circles
    int shape_count = getShapesCount(figure);
    updateShapes(figure);
    for(int index = 0; index < shape_count; index++){
        gShape object = figure->shapes[index];
        string s = to_string(object.x1) + " " + to_string(object.x2) + " " + to_string(object.y1) + " " + to_string(object.y2) + " " + to_string(object.type);
        error_box(s.c_str());
        if(is_line(object)){
            plot->update_scale_by_line(object);
        }
        else if(is_circle(object)){
            plot->update_scale_by_circle(object);
        }
    }
    plot->smooth_scale();

    // plot objects
    for(int index = 0; index < shape_count; index++){
        gShape object = figure->shapes[index];
        if(is_line(object)){
            plot->plot_one_line(object, index);
        }
        else if(is_circle(object)){
            plot->plot_one_circle(object, index);
        }
    }

    // plot intersections
    plot->plot_intersects(point_x, point_y, point_count);

    delete[] point_x;
    delete[] point_y;

    // rescale
    plot->plot_transparent_box();
    plot->show();
}

void SuperWindow::on_pushBotton_AddCircle_clicked()
{
    QString x, y, r;
    x = ui->spin_circle_x->text();
    y = ui->spin_circle_y->text();
    r = ui->spin_circle_r->text();

    // cout << x.toStdString() << y.toStdString() << r.toStdString() << endl;
    // call core function to add circle and plot it.
     try {
        int x_int = x.toInt();
        int y_int = y.toInt();
        int r_int = r.toInt();
        gShape shape = {'C', x_int, y_int, r_int, 0};
        ERROR_INFO info = addShapeToFigure(figure, shape);
        if(info.code != SUCCESS){
            throw exception(info.messages);
        }
        // int id = this->core->addCircle(x_int, y_int, r_int);
        // record
        plot->add_one_circle();
        // Circle c = core->getCircle(id);
        add_to_item(shape.x1, shape.y1, shape.x2);
     } catch (exception &e) {
        string sentence = "[x] Add Circle " + x.toStdString() + " " + y.toStdString() +" " + r.toStdString() + "fail!";
        report(sentence);
        error_box(e.what());
     }
    int points = getPointsCount(figure);
    ui->lineEdit_num_of_intersects->setText(tr(to_string(points).c_str()));
}

void SuperWindow::on_pushBotton_AddLine_clicked()
{
    QString type, x1, x2, y1, y2;
    type = ui->comboBox_line_type->currentText();
    x1 = ui->spin_line_x1->text();
    x2 = ui->spin_line_x2->text();
    y1 = ui->spin_line_y1->text();
    y2 = ui->spin_line_y2->text();

    int x1_int, x2_int, y1_int, y2_int;
    char type_char;
    // call core function to add line and plot it.
    try {
        type_char = (type == "DoubleInfiniteLine") ? 'L' :
                    (type == "SingleInfiniteLine") ? 'R' :
                    (type == "FiniteLine") ? 'S': '?';
        x1_int = x1.toInt();
        x2_int = x2.toInt();
        y1_int = y1.toInt();
        y2_int = y2.toInt();

        gShape line = {type_char, x1_int, y1_int, x2_int, y2_int};
        // int id = this->core->addLine(type_int, x1_int, x2_int, y1_int, y2_int);
        ERROR_INFO info = addShapeToFigure(figure, line);

        if(info.code != SUCCESS){
            throw exception(info.messages);
        }

        // record
        this->plot->add_one_line();
        add_to_item(line.type, line.x1, line.x2, line.y1, line.y2);
    } catch (exception &e) {

        string message = "[x] Add Line " + to_string(type_char) + " " + to_string(x1_int) + " " + to_string(y1_int) +
                " " + to_string(x2_int) + " " + to_string(y2_int) + " fail!";
        report(message);
        error_box(e.what());
    }
    int points_count = getPointsCount(figure);
    ui->lineEdit_num_of_intersects->setText(tr(to_string(points_count).c_str()));
}

void SuperWindow::on_pushBotton_DeleteObject_clicked()
{
    vector<int> delete_rows;
    // foreach (QStandardItem *item, item_model->findItems("*", Qt::MatchWildcard)) {
    for (int i = 0; i < item_model->rowCount(); ++i) {
        QStandardItem *item = item_model->item(i);
        if (item->checkState()) {
            // delete item;
            delete_rows.push_back(i);
        }
    }
    // updateShapes(figure);
    for (int i = delete_rows.size() - 1; i >= 0; --i) {
        try {
            // this->core->remove(id);
            // get name
            QStandardItem *item = item_model->item(delete_rows[i]);
            string object = item->text().toStdString();
            // remove plot graph
            this->plot->remove_object();
            item_model->removeRow(item->index().row());
            removeShapeByIndex(figure, (unsigned int)delete_rows[i]);

            string type = (object.at(0) == 'C') ? "Circle" : "Line";
            string message("[√] Remove " + type + " " + object + " successfully!");
            string ret = "";
            for (u_int i = 0; i < message.length(); ++i) {
                if (message.at(i) == '\t') {
                    ret += " ";
                } else {
                    char tmp[2] = {message.at(i), '\0'};
                    ret += string(tmp);
                }
            }
            report(ret);

        } catch (exception e) {
            QErrorMessage error(this);
            error.showMessage(tr(e.what()));
        }
        int points_count = getPointsCount(figure);
        ui->lineEdit_num_of_intersects->setText(tr(to_string(points_count).c_str()));
    }
}

void SuperWindow::on_pushBotton_LoadFile_clicked()
{
    int count = 0;
    QString fileName = QFileDialog::getOpenFileName(this, "文件导入");
    if (fileName.isEmpty()) {
        QMessageBox::warning(this, "Warning!", "Failed to open the file!");
    }
    else{
        try {
            ifstream reader;
            reader.open(fileName.toStdString().c_str(), ios::in);
            if (!reader.is_open()) {
                error_box("File Open Failed.");
            }
            string line;
            if (!getline(reader, line)) {
                error_box("The first line is empty. ");
            }
            stringstream s(line);
            if (!(s >> count)) {
                error_box("The first line is not a number. ");
            }
            bool flag = false;
            while(count > 0){
                try {
                    getline(reader, line);
                    count-=1;
                    ERROR_INFO info = addShapeToFigureString(figure, line.c_str());
                    if(info.code != SUCCESS){
                        throw exception(info.messages);
                    }
                    updateShapes(figure);
                    gShape shape = figure->shapes[getShapesCount(figure)-1];
                    // int id = this->core->addObjectFromFile(line.c_str());
                    if(is_line(shape)){
                        plot->add_one_line();
                        add_to_item(shape.type, shape.x1, shape.x2, shape.y1, shape.y2);
                    }
                    else if(is_circle(shape)){
                        plot->add_one_circle();
                        add_to_item(shape.x1, shape.y1, shape.x2);
                    }
                } catch (exception& e) {
                    flag = true;
                    string message = "[x] Add Object " + line +" fail!";
                    report(message);
                    string error_message = "[x] " + string(e.what());
                    report(error_message);
                    // error_box(e.what());
                }
            }
            if(flag){
                error_box("Error: Something wrong.");
            }
        } catch (exception& e) {
            error_box(e.what());
        }
        int points_count = getPointsCount(figure);
        ui->lineEdit_num_of_intersects->setText(tr(to_string(points_count).c_str()));
    }
}

void SuperWindow::error_box(const char *s){
    string message = "[x] " + string(s);
    report(message);
    QMessageBox::critical (this, tr("ERROR"), tr(s), QMessageBox::Ok);
}

/*
 * Given an id, ask core if it is a line.
*/
bool SuperWindow::is_line(gShape shape){
    return shape.type == 'L' || shape.type == 'R' || shape.type == 'S';
}

/*
 * Given an id, ask core if it is a circle.
*/
bool SuperWindow::is_circle(gShape shape){
    return shape.type == 'C';
}

void SuperWindow::add_to_item(char type, int x1, int x2, int y1, int y2)
{

    QStandardItem *item;

    item = new QStandardItem(QString("%0\t%1\t%2\t%3\t%4\t").arg(type).arg(x1).arg(y1).arg(x2).arg(y2));
    item->setEditable(false);
    item->setCheckable(true);

    item_model->appendRow(item);
    // item_id[item] = id;

    // report
    char tmp[2] = {type, '\0'};
    string message("[√] Add Line " + string(tmp) + " " + to_string(x1) + " " +
                   to_string(y1) + " " + to_string(x2) + " " + to_string(y2) + " successfully!");
    report(message);
}

void SuperWindow::add_to_item(int x, int y, int r)
{
    QStandardItem *item = new QStandardItem(QString("C\t%0\t%1\t%2").arg(x).arg(y).arg(r));
    item->setEditable(false);
    item->setCheckable(true);

    item_model->appendRow(item);
    // item_id[item] = id;

    // report
    string message("[√] Add Circle C " + to_string(x) + " " +
                   to_string(y) + " " + to_string(r) + " successfully!");
    report(message);
}

void SuperWindow::report(string &message)
{
    QStandardItem *log;
    log = new QStandardItem(QString(message.c_str()));
    log->setEditable(false);
    log->setCheckable(false);
    log_model->appendRow(log);
}
