#pragma once
#include "Constant.h"
#include "DoubleUtils.h"
#include "Exception.h"
#include "GeometryShape.h"
#include "GeometryStatistic.h"
#include "Point.h"
