/********************************************************************************
** Form generated from reading UI file 'superwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.14.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SUPERWINDOW_H
#define UI_SUPERWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_SuperWindow
{
public:
    QWidget *centralwidget;
    QPushButton *pushButton_show;
    QPushButton *pushBotton_AddLine;
    QPushButton *pushBotton_AddCircle;
    QPushButton *pushBotton_DeleteObject;
    QComboBox *comboBox_line_type;
    QSpinBox *spin_line_x1;
    QSpinBox *spin_line_y1;
    QSpinBox *spin_line_x2;
    QSpinBox *spin_line_y2;
    QSpinBox *spin_circle_y;
    QSpinBox *spin_circle_x;
    QSpinBox *spin_circle_r;
    QPushButton *pushBotton_LoadFile;
    QListView *logView;
    QLabel *label_addLine_type;
    QLabel *label_addLine_x1;
    QLabel *label_addLine_y1;
    QLabel *label_addLine_x2;
    QLabel *label_addLine_y2;
    QLabel *label_addCircle_x;
    QLabel *label_addCircle_y;
    QLabel *label_addCircle_r;
    QLineEdit *lineEdit_num_of_intersects;
    QLabel *label_addCircle_x_2;
    QListView *objectView;
    QLabel *label_addCircle_x_3;
    QLabel *label_addCircle_x_4;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *SuperWindow)
    {
        if (SuperWindow->objectName().isEmpty())
            SuperWindow->setObjectName(QString::fromUtf8("SuperWindow"));
        SuperWindow->resize(1095, 701);
        SuperWindow->setDockOptions(QMainWindow::AllowTabbedDocks|QMainWindow::AnimatedDocks);
        centralwidget = new QWidget(SuperWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        pushButton_show = new QPushButton(centralwidget);
        pushButton_show->setObjectName(QString::fromUtf8("pushButton_show"));
        pushButton_show->setGeometry(QRect(508, 252, 93, 28));
        pushBotton_AddLine = new QPushButton(centralwidget);
        pushBotton_AddLine->setObjectName(QString::fromUtf8("pushBotton_AddLine"));
        pushBotton_AddLine->setGeometry(QRect(65, 38, 121, 28));
        pushBotton_AddCircle = new QPushButton(centralwidget);
        pushBotton_AddCircle->setObjectName(QString::fromUtf8("pushBotton_AddCircle"));
        pushBotton_AddCircle->setGeometry(QRect(66, 157, 121, 28));
        pushBotton_DeleteObject = new QPushButton(centralwidget);
        pushBotton_DeleteObject->setObjectName(QString::fromUtf8("pushBotton_DeleteObject"));
        pushBotton_DeleteObject->setGeometry(QRect(66, 240, 121, 28));
        comboBox_line_type = new QComboBox(centralwidget);
        comboBox_line_type->addItem(QString());
        comboBox_line_type->addItem(QString());
        comboBox_line_type->addItem(QString());
        comboBox_line_type->setObjectName(QString::fromUtf8("comboBox_line_type"));
        comboBox_line_type->setGeometry(QRect(361, 127, 181, 22));
        comboBox_line_type->setMaxVisibleItems(10);
        spin_line_x1 = new QSpinBox(centralwidget);
        spin_line_x1->setObjectName(QString::fromUtf8("spin_line_x1"));
        spin_line_x1->setGeometry(QRect(363, 40, 71, 22));
        spin_line_x1->setMinimum(-99999);
        spin_line_x1->setMaximum(99999);
        spin_line_y1 = new QSpinBox(centralwidget);
        spin_line_y1->setObjectName(QString::fromUtf8("spin_line_y1"));
        spin_line_y1->setGeometry(QRect(472, 40, 71, 22));
        spin_line_y1->setMinimum(-99999);
        spin_line_y1->setMaximum(99999);
        spin_line_x2 = new QSpinBox(centralwidget);
        spin_line_x2->setObjectName(QString::fromUtf8("spin_line_x2"));
        spin_line_x2->setGeometry(QRect(364, 88, 71, 22));
        spin_line_x2->setMinimum(-99999);
        spin_line_x2->setMaximum(99999);
        spin_line_y2 = new QSpinBox(centralwidget);
        spin_line_y2->setObjectName(QString::fromUtf8("spin_line_y2"));
        spin_line_y2->setGeometry(QRect(473, 88, 71, 22));
        spin_line_y2->setMinimum(-99999);
        spin_line_y2->setMaximum(99999);
        spin_circle_y = new QSpinBox(centralwidget);
        spin_circle_y->setObjectName(QString::fromUtf8("spin_circle_y"));
        spin_circle_y->setGeometry(QRect(364, 160, 71, 22));
        spin_circle_y->setMinimum(-99999);
        spin_circle_y->setMaximum(99999);
        spin_circle_x = new QSpinBox(centralwidget);
        spin_circle_x->setObjectName(QString::fromUtf8("spin_circle_x"));
        spin_circle_x->setGeometry(QRect(251, 160, 71, 22));
        spin_circle_x->setMinimum(-99999);
        spin_circle_x->setMaximum(99999);
        spin_circle_r = new QSpinBox(centralwidget);
        spin_circle_r->setObjectName(QString::fromUtf8("spin_circle_r"));
        spin_circle_r->setGeometry(QRect(473, 160, 71, 22));
        spin_circle_r->setMinimum(1);
        spin_circle_r->setMaximum(99999);
        pushBotton_LoadFile = new QPushButton(centralwidget);
        pushBotton_LoadFile->setObjectName(QString::fromUtf8("pushBotton_LoadFile"));
        pushBotton_LoadFile->setGeometry(QRect(66, 200, 121, 28));
        logView = new QListView(centralwidget);
        logView->setObjectName(QString::fromUtf8("logView"));
        logView->setGeometry(QRect(630, 20, 441, 591));
        label_addLine_type = new QLabel(centralwidget);
        label_addLine_type->setObjectName(QString::fromUtf8("label_addLine_type"));
        label_addLine_type->setGeometry(QRect(327, 130, 31, 16));
        label_addLine_x1 = new QLabel(centralwidget);
        label_addLine_x1->setObjectName(QString::fromUtf8("label_addLine_x1"));
        label_addLine_x1->setGeometry(QRect(342, 42, 31, 16));
        label_addLine_y1 = new QLabel(centralwidget);
        label_addLine_y1->setObjectName(QString::fromUtf8("label_addLine_y1"));
        label_addLine_y1->setGeometry(QRect(451, 43, 31, 16));
        label_addLine_x2 = new QLabel(centralwidget);
        label_addLine_x2->setObjectName(QString::fromUtf8("label_addLine_x2"));
        label_addLine_x2->setGeometry(QRect(343, 91, 31, 16));
        label_addLine_y2 = new QLabel(centralwidget);
        label_addLine_y2->setObjectName(QString::fromUtf8("label_addLine_y2"));
        label_addLine_y2->setGeometry(QRect(451, 91, 31, 16));
        label_addCircle_x = new QLabel(centralwidget);
        label_addCircle_x->setObjectName(QString::fromUtf8("label_addCircle_x"));
        label_addCircle_x->setGeometry(QRect(235, 162, 31, 16));
        label_addCircle_y = new QLabel(centralwidget);
        label_addCircle_y->setObjectName(QString::fromUtf8("label_addCircle_y"));
        label_addCircle_y->setGeometry(QRect(346, 163, 31, 16));
        label_addCircle_r = new QLabel(centralwidget);
        label_addCircle_r->setObjectName(QString::fromUtf8("label_addCircle_r"));
        label_addCircle_r->setGeometry(QRect(455, 162, 31, 16));
        lineEdit_num_of_intersects = new QLineEdit(centralwidget);
        lineEdit_num_of_intersects->setObjectName(QString::fromUtf8("lineEdit_num_of_intersects"));
        lineEdit_num_of_intersects->setEnabled(true);
        lineEdit_num_of_intersects->setGeometry(QRect(386, 255, 113, 21));
        lineEdit_num_of_intersects->setReadOnly(true);
        label_addCircle_x_2 = new QLabel(centralwidget);
        label_addCircle_x_2->setObjectName(QString::fromUtf8("label_addCircle_x_2"));
        label_addCircle_x_2->setGeometry(QRect(252, 255, 131, 20));
        objectView = new QListView(centralwidget);
        objectView->setObjectName(QString::fromUtf8("objectView"));
        objectView->setGeometry(QRect(40, 290, 561, 321));
        label_addCircle_x_3 = new QLabel(centralwidget);
        label_addCircle_x_3->setObjectName(QString::fromUtf8("label_addCircle_x_3"));
        label_addCircle_x_3->setGeometry(QRect(250, 620, 161, 20));
        label_addCircle_x_4 = new QLabel(centralwidget);
        label_addCircle_x_4->setObjectName(QString::fromUtf8("label_addCircle_x_4"));
        label_addCircle_x_4->setGeometry(QRect(850, 620, 131, 20));
        SuperWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(SuperWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 1095, 26));
        SuperWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(SuperWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        SuperWindow->setStatusBar(statusbar);

        retranslateUi(SuperWindow);

        QMetaObject::connectSlotsByName(SuperWindow);
    } // setupUi

    void retranslateUi(QMainWindow *SuperWindow)
    {
        SuperWindow->setWindowTitle(QCoreApplication::translate("SuperWindow", "MainWindow", nullptr));
        pushButton_show->setText(QCoreApplication::translate("SuperWindow", "\347\273\230\345\233\276", nullptr));
        pushBotton_AddLine->setText(QCoreApplication::translate("SuperWindow", "\346\267\273\345\212\240\347\272\277\347\261\273\345\233\276\345\275\242", nullptr));
        pushBotton_AddCircle->setText(QCoreApplication::translate("SuperWindow", "\346\267\273\345\212\240\345\234\206\345\275\242\345\233\276\345\275\242", nullptr));
        pushBotton_DeleteObject->setText(QCoreApplication::translate("SuperWindow", "\345\210\240\351\231\244\346\211\200\351\200\211\351\203\250\344\273\266", nullptr));
        comboBox_line_type->setItemText(0, QCoreApplication::translate("SuperWindow", "DoubleInfiniteLine", nullptr));
        comboBox_line_type->setItemText(1, QCoreApplication::translate("SuperWindow", "SingleInfiniteLine", nullptr));
        comboBox_line_type->setItemText(2, QCoreApplication::translate("SuperWindow", "FiniteLine", nullptr));

        pushBotton_LoadFile->setText(QCoreApplication::translate("SuperWindow", "\345\212\240\350\275\275\346\226\207\344\273\266", nullptr));
        label_addLine_type->setText(QCoreApplication::translate("SuperWindow", "\347\261\273\345\236\213", nullptr));
        label_addLine_x1->setText(QCoreApplication::translate("SuperWindow", "x1", nullptr));
        label_addLine_y1->setText(QCoreApplication::translate("SuperWindow", "y1", nullptr));
        label_addLine_x2->setText(QCoreApplication::translate("SuperWindow", "x2", nullptr));
        label_addLine_y2->setText(QCoreApplication::translate("SuperWindow", "y2", nullptr));
        label_addCircle_x->setText(QCoreApplication::translate("SuperWindow", "x", nullptr));
        label_addCircle_y->setText(QCoreApplication::translate("SuperWindow", "y", nullptr));
        label_addCircle_r->setText(QCoreApplication::translate("SuperWindow", "r", nullptr));
        lineEdit_num_of_intersects->setText(QCoreApplication::translate("SuperWindow", "0", nullptr));
        label_addCircle_x_2->setText(QCoreApplication::translate("SuperWindow", "Num Of Intersects", nullptr));
        label_addCircle_x_3->setText(QCoreApplication::translate("SuperWindow", "Objects", nullptr));
        label_addCircle_x_4->setText(QCoreApplication::translate("SuperWindow", "Log", nullptr));
    } // retranslateUi

};

namespace Ui {
    class SuperWindow: public Ui_SuperWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SUPERWINDOW_H
